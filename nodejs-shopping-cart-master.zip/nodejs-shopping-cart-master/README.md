

csurf
- https://www.npmjs.com/package/csurf
- https://github.com/pillarjs/understanding-csrf

Instalacion:
- en la carpeta seed: se encuntra productos de ejemplo, nanvega
  hasta la carpeta y ejecuta el comando : `node product-seeder.js`


  pseudocódigo, diagramas de flujo y diagramas
  Nassi-Schneiderman
